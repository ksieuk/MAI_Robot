#include "Camera.h"
#include <iostream>

void Camera::get_image() {
	std::cout << "Get Image";
}

void Camera::update_image() {
	std::cout << "Update Image";
}