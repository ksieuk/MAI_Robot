#include "Robot.h"
#include <iostream>

void Robot::moveForward() {
	std::cout << "Forward";
}

void Robot::setAngle() {
	std::cout << "Angle";
}

void Robot::moveBack() {
	std::cout << "Back";
}

void Robot::stop() {
	std::cout << "Stopped";
}