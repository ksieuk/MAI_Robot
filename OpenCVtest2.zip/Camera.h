#pragma once

class Camera {
public:
	void get_image();
	void update_image();
};