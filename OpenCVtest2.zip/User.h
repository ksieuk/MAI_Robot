#pragma once

class User {
public:
	void makeOrder();
};
