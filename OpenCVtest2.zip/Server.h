#pragma once

class Server {
public:
	void findRobot();
	void findPuf();
	void startRouting();
	void calcDestination();
};
