#pragma once

class Order {
private:
	int puf;
	int numOrder;
	int status;
};