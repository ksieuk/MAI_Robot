#include "User.h"
#include <iostream>

void User::makeOrder() {
	std::cout << "Make Order";
}