#include "Server.h"
#include <iostream>

void Server::findRobot() {
	std::cout << "Find in Process";
}

void Server::findPuf() {
	std::cout << "Find Puf in Process";
}

void Server::startRouting() {
	std::cout << "Start in Process";
}
void Server::calcDestination() {
	std::cout << "Calc in Process";
}
